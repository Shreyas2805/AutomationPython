# -*- coding: utf-8 -*-
"""
Created on Tue Sep 29 05:46:31 2020

@author: Suraj
"""
import os
import logging
import logging.config
import logging.handlers

def getLogger(identifier):
    #logger will use rotating file handler. Log file MaxSIze=1 MB with rotation enabled upto 10 files.
    if not os.path.isdir("logs"):
        os.makedirs("logs")
    logging.config.fileConfig("log.conf")
    return logging.getLogger(identifier)
from cryptography.fernet import Fernet


class AES():

    @staticmethod
    def __getKey():
        key = 'woH7yz0voaXTh7XqcBGrj5MocI2Q3R_cvOlIDoX5GLQ='
        finalKey = key.encode('utf-8')
        return finalKey

    @staticmethod
    def __encryptWithKey(plainText: str, key: bytes):
        cipher = Fernet(key)
        encryptedText = cipher.encrypt(plainText.encode('utf-8'))
        return encryptedText.decode()

    @staticmethod
    def __decryptWithKey(encryptedText: str, key: bytes):
        cipher = Fernet(key)
        plainText = cipher.decrypt(encryptedText.encode('utf-8'))
        return plainText.decode()

 
    @staticmethod
    def encrypt(plainText: str):
        encryptedMessage = AES.__encryptWithKey(plainText,AES.__getKey())
        return encryptedMessage

    @staticmethod
    def decrypt(cipherText: str):
        plainText = AES.__decryptWithKey(cipherText,AES.__getKey())
        return plainText